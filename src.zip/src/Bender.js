import { Link } from "react-router-dom";
import axios from "axios";
import React from "react";

class Bender extends React.Component {
  render() {
    return (
      <div>
        <h2>Bender</h2>
      </div>
    );
  }
}

export default Bender;
